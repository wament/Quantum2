
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/william-ament/Documents/Quantum2/main.cpp" "CMakeFiles/Blackjack2.dir/main.cpp.obj" "gcc" "CMakeFiles/Blackjack2.dir/main.cpp.obj.d"
  "/home/william-ament/Documents/Quantum2/src/Card.cpp" "CMakeFiles/Blackjack2.dir/src/Card.cpp.obj" "gcc" "CMakeFiles/Blackjack2.dir/src/Card.cpp.obj.d"
  "/home/william-ament/Documents/Quantum2/src/Deck.cpp" "CMakeFiles/Blackjack2.dir/src/Deck.cpp.obj" "gcc" "CMakeFiles/Blackjack2.dir/src/Deck.cpp.obj.d"
  "/home/william-ament/Documents/Quantum2/src/FontManager.cpp" "CMakeFiles/Blackjack2.dir/src/FontManager.cpp.obj" "gcc" "CMakeFiles/Blackjack2.dir/src/FontManager.cpp.obj.d"
  "/home/william-ament/Documents/Quantum2/src/Game.cpp" "CMakeFiles/Blackjack2.dir/src/Game.cpp.obj" "gcc" "CMakeFiles/Blackjack2.dir/src/Game.cpp.obj.d"
  "/home/william-ament/Documents/Quantum2/src/Graphics.cpp" "CMakeFiles/Blackjack2.dir/src/Graphics.cpp.obj" "gcc" "CMakeFiles/Blackjack2.dir/src/Graphics.cpp.obj.d"
  "/home/william-ament/Documents/Quantum2/src/HUD.cpp" "CMakeFiles/Blackjack2.dir/src/HUD.cpp.obj" "gcc" "CMakeFiles/Blackjack2.dir/src/HUD.cpp.obj.d"
  "/home/william-ament/Documents/Quantum2/src/Hand.cpp" "CMakeFiles/Blackjack2.dir/src/Hand.cpp.obj" "gcc" "CMakeFiles/Blackjack2.dir/src/Hand.cpp.obj.d"
  "/home/william-ament/Documents/Quantum2/src/Panel.cpp" "CMakeFiles/Blackjack2.dir/src/Panel.cpp.obj" "gcc" "CMakeFiles/Blackjack2.dir/src/Panel.cpp.obj.d"
  "/home/william-ament/Documents/Quantum2/src/Player.cpp" "CMakeFiles/Blackjack2.dir/src/Player.cpp.obj" "gcc" "CMakeFiles/Blackjack2.dir/src/Player.cpp.obj.d"
  "/home/william-ament/Documents/Quantum2/src/PlayerProfile.cpp" "CMakeFiles/Blackjack2.dir/src/PlayerProfile.cpp.obj" "gcc" "CMakeFiles/Blackjack2.dir/src/PlayerProfile.cpp.obj.d"
  "/home/william-ament/Documents/Quantum2/src/StatBox.cpp" "CMakeFiles/Blackjack2.dir/src/StatBox.cpp.obj" "gcc" "CMakeFiles/Blackjack2.dir/src/StatBox.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
