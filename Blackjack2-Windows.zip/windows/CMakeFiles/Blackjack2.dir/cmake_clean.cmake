file(REMOVE_RECURSE
  "Blackjack2.exe"
  "Blackjack2.pdb"
  "CMakeFiles/Blackjack2.dir/main.cpp.obj"
  "CMakeFiles/Blackjack2.dir/main.cpp.obj.d"
  "CMakeFiles/Blackjack2.dir/src/Card.cpp.obj"
  "CMakeFiles/Blackjack2.dir/src/Card.cpp.obj.d"
  "CMakeFiles/Blackjack2.dir/src/Deck.cpp.obj"
  "CMakeFiles/Blackjack2.dir/src/Deck.cpp.obj.d"
  "CMakeFiles/Blackjack2.dir/src/FontManager.cpp.obj"
  "CMakeFiles/Blackjack2.dir/src/FontManager.cpp.obj.d"
  "CMakeFiles/Blackjack2.dir/src/Game.cpp.obj"
  "CMakeFiles/Blackjack2.dir/src/Game.cpp.obj.d"
  "CMakeFiles/Blackjack2.dir/src/Graphics.cpp.obj"
  "CMakeFiles/Blackjack2.dir/src/Graphics.cpp.obj.d"
  "CMakeFiles/Blackjack2.dir/src/HUD.cpp.obj"
  "CMakeFiles/Blackjack2.dir/src/HUD.cpp.obj.d"
  "CMakeFiles/Blackjack2.dir/src/Hand.cpp.obj"
  "CMakeFiles/Blackjack2.dir/src/Hand.cpp.obj.d"
  "CMakeFiles/Blackjack2.dir/src/Panel.cpp.obj"
  "CMakeFiles/Blackjack2.dir/src/Panel.cpp.obj.d"
  "CMakeFiles/Blackjack2.dir/src/Player.cpp.obj"
  "CMakeFiles/Blackjack2.dir/src/Player.cpp.obj.d"
  "CMakeFiles/Blackjack2.dir/src/PlayerProfile.cpp.obj"
  "CMakeFiles/Blackjack2.dir/src/PlayerProfile.cpp.obj.d"
  "CMakeFiles/Blackjack2.dir/src/StatBox.cpp.obj"
  "CMakeFiles/Blackjack2.dir/src/StatBox.cpp.obj.d"
  "libBlackjack2.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/Blackjack2.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
