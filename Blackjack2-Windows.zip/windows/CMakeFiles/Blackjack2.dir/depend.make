# Empty dependencies file for Blackjack2.
# This may be replaced when dependencies are built.
