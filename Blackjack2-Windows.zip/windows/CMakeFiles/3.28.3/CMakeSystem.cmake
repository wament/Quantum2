set(CMAKE_HOST_SYSTEM "Linux-7.0.0-28-generic")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "7.0.0-28-generic")
set(CMAKE_HOST_SYSTEM_PROCESSOR "x86_64")

include("/home/william-ament/Documents/Quantum2/mingw-win64-toolchain.cmake")

set(CMAKE_SYSTEM "Windows-10")
set(CMAKE_SYSTEM_NAME "Windows")
set(CMAKE_SYSTEM_VERSION "10")
set(CMAKE_SYSTEM_PROCESSOR "")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
